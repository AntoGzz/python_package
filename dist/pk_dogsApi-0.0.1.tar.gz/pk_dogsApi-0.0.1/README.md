# Instructivo de instalación
    Paquete para listar todas las Razas de Perros disponibles desde una API pública.

###### 1. Iniciar entorno virtual
`py -m venv env ó python -m venv env`

###### 2. Activar el entorno virtual 
`source env/Scripts/activate`

###### 3. Instalar el paquete
`pip install pk_dogsApi`